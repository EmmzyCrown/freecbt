module.exports = {
    homepage: "https://freecbt.erosson.org/webapp",
}
